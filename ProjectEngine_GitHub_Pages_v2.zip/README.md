# ProjectEngine GitHub Pages

Static landing page for:

https://tmailletfr.github.io/ProjectEngine/

## Deployment

Recommended deployment method: a dedicated `gh-pages` branch.

1. Create a new orphan branch named `gh-pages`.
2. Copy the contents of this folder to the root of that branch.
3. Commit and push the branch.
4. In the repository, open `Settings → Pages`.
5. Under `Build and deployment`, select `Deploy from a branch`.
6. Select branch `gh-pages` and folder `/ (root)`.
7. Save.

The site is a plain static site. No build process, package manager or dependency is required.

## Included SEO files

- canonical URL
- Open Graph and Twitter metadata
- SoftwareApplication structured data
- robots.txt
- sitemap.xml
- custom 404 page
- favicon
- `.nojekyll`


## v2 corrections

- Hero slogan locked to two lines on desktop.
- Workflow fit panel vertically centered.
- Analytics and S-Curve cards retain their natural image ratios.
- Download CTAs use `download.html`, which resolves the `.xlsm` asset from the latest GitHub release dynamically.
